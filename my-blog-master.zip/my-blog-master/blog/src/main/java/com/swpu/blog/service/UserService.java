package com.swpu.blog.service;

import com.swpu.blog.entity.User;

public interface UserService {
    public User login(String username, String password);

}
