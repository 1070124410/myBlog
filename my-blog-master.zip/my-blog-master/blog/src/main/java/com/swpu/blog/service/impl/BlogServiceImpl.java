package com.swpu.blog.service.impl;

import com.swpu.blog.config.NotFoundException;
import com.swpu.blog.entity.Blog;
import com.swpu.blog.mapper.BlogMapper;
import com.swpu.blog.service.BlogService;
import com.swpu.blog.service.TagService;
import com.swpu.blog.utils.MarkdownUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class BlogServiceImpl implements BlogService {
    @Autowired
    private BlogMapper blogMapper;

    @Autowired
    private TagService tagService;

    @Override
    public List<Blog> getAllBlog() {
        return blogMapper.getAllBlog();
    }

    @Override
    public int saveBlog(Blog blog) {
        blogMapper.cancelCon();
        if(blog.getId()==0){
            blog.setUpdateTime(new Date());
            blog.setViews(0);
            int i = blogMapper.saveBlog(blog);
            blogMapper.confirmCon();
            return i;
        }else{
            blog.setUpdateTime(new Date());
            blogMapper.confirmCon();
            return 0;
        }
    }

    @Override
    public Blog getBlogById(Long id) {
        return blogMapper.getBlogById(id);
    }

    @Override
    public int deleteBlog(Long id) {
        blogMapper.cancelCon();
        blogMapper.deleteComment(id);
        int i = blogMapper.deleteBlog(id);
        blogMapper.confirmCon();
        return i;
    }

    @Override
    public int updateBlog(Blog blog) {
        blogMapper.cancelCon();
        blog.setUpdateTime(new Date());
        int i = blogMapper.updateBlog(blog);
        blogMapper.confirmCon();
        return i;
    }

    @Override
    public List<Blog> searchBlog(Blog blog) {
        return blogMapper.searchBlog(blog);
    }





    @Override
    public Integer countBlog() {
        return blogMapper.countBlog();
    }

    @Override
    public Map<String, List<Blog>> archiveBlog() {
        List<String> years=blogMapper.findGroupYear();
        Map<String, List<Blog>> map=new HashMap<>();
        for(String year:years){
            map.put(year,blogMapper.findByYear(year));
        }
        return map;
    }

    @Override
    public List<Blog> getBlogByTypeId(Long typeId) {
        return blogMapper.getBlogByTypeId(typeId);
    }

    @Override
    public List<Blog> getBlogByTagId(Long tagId) {
        return blogMapper.getBlogByTagId(tagId);
    }

    @Override
    public List<Blog> getIndexBlog() {
        return blogMapper.getIndexBlog();
    }

    @Override
    public List<Blog> getRecommendBlog() {
        return blogMapper.getRecommendBlog();
    }

    @Override
    public List<Blog> searchIndexBlog(String query) {
        return blogMapper.searchIndexBlog(query);
    }

    @Override
    public Blog getDetailedBlog(Long id) {
        Blog blog=blogMapper.getDetailedBlog(id);
        if(blog==null){
            throw new NotFoundException("该博客不存在");
        }

        List tags = new ArrayList();
        if(blog.getTagIds()=="" || blog.getTagIds().equals("")){

        }else{
            String[] tagIds=blog.getTagIds().split(",");
            for(String tagId:tagIds){
                Long tagid=Long.parseLong(tagId);
                tags.add(tagService.getTagById(tagid));
            }
            blog.setTags(tags);
        }

        String content=blog.getContent();
        blog.setContent(MarkdownUtils.markdownToHtmlExtensions(content));

        blogMapper.updateViews(id);
        return blog;
    }


}
