package com.swpu.blog.mapper;

import com.swpu.blog.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Component
@Mapper
@Repository
public interface UserMapper {
    public User login(String username, String password);
}
