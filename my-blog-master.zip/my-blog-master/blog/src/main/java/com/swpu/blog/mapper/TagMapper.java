package com.swpu.blog.mapper;

import com.swpu.blog.entity.Tag;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.List;

@Component
@Mapper
@Repository
public interface TagMapper{
    public List<Tag> getAllTag();
    public Tag getTagById(@Param("id") Long id);
    public Tag getTagByName(@Param("name") String name);
    public void saveTag(Tag tag);
    public void updateTag(Tag tag);
    public void deleteTag(Long id);
}
