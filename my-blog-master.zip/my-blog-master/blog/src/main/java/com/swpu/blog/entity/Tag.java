package com.swpu.blog.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Tag {
    /**编号*/
    private Long id;

    /**标签名*/
    private String name;

    /**级联关系*/
    private List<com.swpu.blog.entity.Blog> blogs = new ArrayList<>();
}
