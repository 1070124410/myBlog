package com.swpu.blog.service;

import com.swpu.blog.entity.Comment;

import java.util.List;

public interface CommentService {
    public void saveComment(Comment comment);
    public List<Comment> getCommentByBlogId(Long blogId);
}
