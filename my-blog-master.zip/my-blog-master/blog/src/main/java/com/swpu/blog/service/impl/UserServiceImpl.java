package com.swpu.blog.service.impl;

import com.swpu.blog.entity.User;
import com.swpu.blog.mapper.UserMapper;
import com.swpu.blog.service.UserService;
import com.swpu.blog.utils.MD5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;

    @Transactional
    @Override
    public User login(String username, String password) {
        return userMapper.login(username, MD5Util.code(password));
    }
}
