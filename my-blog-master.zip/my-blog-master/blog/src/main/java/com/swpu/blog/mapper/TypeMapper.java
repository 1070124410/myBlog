package com.swpu.blog.mapper;

import com.swpu.blog.entity.Type;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.List;

@Component
@Mapper
@Repository
public interface TypeMapper{
    public List<Type> getAllType();
    public Type getTypeById(@Param("id")Long id);
    public Type getTypeByName(@Param("name")String name);
    public void saveType(Type type);
    public void updateType(Type type);
    public void deleteType(Long id);


}
