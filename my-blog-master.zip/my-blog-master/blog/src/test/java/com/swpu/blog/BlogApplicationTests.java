package com.swpu.blog;

import com.swpu.blog.service.TypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;



@SpringBootTest
class BlogApplicationTests {
      @Autowired
    TypeService typeService;
}








